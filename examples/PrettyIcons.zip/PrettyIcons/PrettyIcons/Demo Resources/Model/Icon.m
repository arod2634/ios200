#import "Icon.h"

@implementation Icon

- (instancetype)initWithTitle:(NSString *)title subtitle:(NSString *)subtitle imageName:(NSString *)imageName {
  if ((self = [super init])) {
    self.title = title;
    self.subtitle = subtitle;
    self.image = [UIImage imageNamed:imageName];
    self.rating = RatingTypeUnrated;
  }
  return self;
}

@end