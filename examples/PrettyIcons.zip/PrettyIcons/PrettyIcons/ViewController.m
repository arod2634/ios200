#import "ViewController.h"
#import "IconSet.h"
#import "Icon.h"

@interface ViewController ()

@property (strong, nonatomic) NSArray *icons;

@end

@implementation ViewController

- (void)viewDidLoad
{
  [super viewDidLoad];
  NSArray *iconSets = [IconSet iconSets];
  IconSet *set = (IconSet *)iconSets[1];
  self.icons = set.icons;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
  return self.icons.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

  UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"IconCell" forIndexPath:indexPath];
    
  if (indexPath.row % 2) {
      cell.backgroundColor = [[UIColor alloc]initWithRed:180.0/255.0 green:180.0/255.0 blue:180.0/255.0 alpha:1];
  }
    
  Icon *icon = self.icons[indexPath.row];
  cell.textLabel.text = icon.title;
  cell.detailTextLabel.text = icon.subtitle;
  cell.imageView.image = icon.image;
  
  return cell;  
}

/*- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSLog(@"touch on row %ld", (long)indexPath.row);
}*/

@end
