//
//  main.m
//  DexterDelegates
//
//  Created by Alex Rodriguez on 10/27/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Dexter.h"
#import "Alex.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        Dexter *dexter = [[Dexter alloc] init];
        Alex *alex = [[Alex alloc] init];
        
        dexter.caretaker = alex;
        
        [dexter hasToGoBathroom];
        [dexter isHungry];
        
    }
    return 0;
}
