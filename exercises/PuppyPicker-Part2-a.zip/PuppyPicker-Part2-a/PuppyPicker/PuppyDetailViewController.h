//
//  PuppyDetailViewController.h
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/16/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Puppy.h"

@interface PuppyDetailViewController : UIViewController

@property (nonatomic, weak) Puppy *puppyDetails;

@end
