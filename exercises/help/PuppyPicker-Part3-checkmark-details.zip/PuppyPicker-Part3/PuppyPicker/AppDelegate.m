//
//  AppDelegate.m
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/11/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import "AppDelegate.h"
#import "Puppy.h"
#import "PuppyListViewController.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    return YES;
}

@end
