//
//  NewPuppyViewController.h
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/16/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Puppy.h"

@class NewPuppyViewController;

@protocol NewPuppyViewControllerDelegate <NSObject>

- (void)newPuppyViewControllerDidCancel:(NewPuppyViewController *)controller;
- (void)newPuppyViewController:(NewPuppyViewController *)controller didAddPuppy:(Puppy *)puppy;

@end

@interface NewPuppyViewController : UITableViewController

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UILabel *ageLabel;
@property (weak, nonatomic) IBOutlet UILabel *popularityLabel;


@property (nonatomic, strong) id <NewPuppyViewControllerDelegate> delegate;

- (IBAction)cancel:(id)sender;
- (IBAction)done:(id)sender;

@end
