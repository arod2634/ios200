//
//  NewPuppyDetailViewController.m
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/16/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import "NewPuppyDetailViewController.h"

@interface NewPuppyDetailViewController ()

@property (nonatomic, strong) NSArray *options;
@property (nonatomic) int selectedIndex;

@end

@implementation NewPuppyDetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if (self.didSelectAge) {
        self.options = @[@"1 Month", @"2 Months", @"3 Months", @"4 Months", @"5 Months", @"6 Months", @"7 Months", @"8 Months", @"9  Months", @"10 Months", @"11 Months", @"1 Year"];
    } else {
        self.options = @[@"1",@"2",@"3",@"4",@"5"];
    }
    
    self.selectedIndex = [self.options indexOfObject:self.option];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.options count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DetailCell"];
    cell.textLabel.text = self.options[indexPath.row];
    
    if (indexPath.row == self.selectedIndex) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (self.selectedIndex != NSNotFound) {
        UITableViewCell *cell = [tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:self.selectedIndex inSection:0]];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    self.selectedIndex = indexPath.row;
    
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    
    NSString *option = self.options[indexPath.row];
    [self.delegate NewPuppyDetailViewController:self didSelectOption:option forAge:(BOOL)self.didSelectAge];
}

@end
