//
//  NewPuppyViewController.m
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/16/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import "NewPuppyViewController.h"
#import "Puppy.h"
#import "NewPuppyDetailViewController.h"

@interface NewPuppyViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, NewPuppyDetailViewControllerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (nonatomic, strong) NSString *ageOption;
@property (nonatomic, strong) NSString *popularityOption;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation NewPuppyViewController

- (void)viewDidLoad
{
    self.nameTextField.delegate = self;
    
    self.ageOption = @"1 Year";
    self.ageLabel.text = self.ageOption;
    
    self.popularityOption =  @"5";
    self.popularityLabel.text = self.popularityOption;
    
}

- (void)NewPuppyDetailViewController:(NewPuppyDetailViewController *)controller didSelectOption:(NSString *)option forAge:(BOOL)didSelectAge
{
    if (didSelectAge) {
        self.ageOption = option;
        self.ageLabel.text = self.ageOption;
    } else {
        self.popularityOption = option;
        self.popularityLabel.text = self.popularityOption;
    }
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)done:(id)sender
{
    Puppy *newPuppy = [[Puppy alloc] init];
    newPuppy.name = self.nameTextField.text;
    newPuppy.age = self.ageOption;
    newPuppy.popularity = [self.popularityOption integerValue];
    newPuppy.photo = self.imageView.image;
    
    [self.delegate newPuppyViewController:self didAddPuppy:newPuppy];
}

- (IBAction)cancel:(id)sender
{
    [self.delegate newPuppyViewControllerDidCancel:self];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

- (IBAction)didSelectPhoto:(id)sender
{
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.delegate = self;
    picker.allowsEditing = YES;
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:picker animated:YES completion:NULL];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    
    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
    self.imageView.image = chosenImage;
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {

    [picker dismissViewControllerAnimated:YES completion:NULL];
    
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    NewPuppyDetailViewController *detailsVC = (NewPuppyDetailViewController *) segue.destinationViewController;
    detailsVC.delegate = self;
    
    if ([segue.identifier isEqualToString:@"PickAge"]) {
        detailsVC.didSelectAge = YES;
        detailsVC.option = self.ageLabel.text;
    }
    else if ([segue.identifier isEqualToString:@"PickPopularity"]) {
        detailsVC.didSelectAge = NO;
        detailsVC.option = self.popularityLabel.text;
    }
}

@end
