//
//  NewPuppyDetailViewController.h
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/16/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import <UIKit/UIKit.h>

@class NewPuppyDetailViewController;

@protocol NewPuppyDetailViewControllerDelegate <NSObject>

- (void)NewPuppyDetailViewController:(NewPuppyDetailViewController *)controller didSelectOption:(NSString *)option forAge:(BOOL)didSelectAge;

@end

@interface NewPuppyDetailViewController : UITableViewController

@property (nonatomic, weak) id <NewPuppyDetailViewControllerDelegate> delegate;
@property (nonatomic, strong) NSString *option;
@property (nonatomic) BOOL didSelectAge;

@end
