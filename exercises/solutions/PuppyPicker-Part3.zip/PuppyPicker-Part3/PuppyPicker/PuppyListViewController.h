//
//  PuppyListViewController.h
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/12/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PuppyListViewController : UITableViewController

@end
