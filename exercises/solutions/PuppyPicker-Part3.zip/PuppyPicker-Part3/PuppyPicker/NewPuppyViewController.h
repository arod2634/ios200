//
//  NewPuppyViewController.h
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/16/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Puppy.h"

@class NewPuppyViewController;

@protocol NewPuppyViewControllerDelegate <NSObject>

- (void)newPuppyViewControllerDidCancel:(NewPuppyViewController *)controller;
- (void)newPuppyViewController:(NewPuppyViewController *)controller didAddPuppy:(Puppy *)puppy;

@end

@interface NewPuppyViewController : UITableViewController

@property (nonatomic, strong) id <NewPuppyViewControllerDelegate> delegate;

@end
