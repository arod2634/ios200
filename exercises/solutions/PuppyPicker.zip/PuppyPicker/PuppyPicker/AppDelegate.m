//
//  AppDelegate.m
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/11/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import "AppDelegate.h"
#import "Puppy.h"
#import "PuppyListViewController.h"

@implementation AppDelegate
{
    NSMutableArray *puppies;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{

    puppies = [NSMutableArray arrayWithCapacity:3];
    
    Puppy *puppy = [[Puppy alloc] init];
    puppy.name = @"Rocky";
    puppy.age = @"2 Months";
    puppy.popularity = 5;
    [puppies addObject:puppy];
    
    puppy = [[Puppy alloc] init];
    puppy.name = @"Cocoa";
    puppy.age = @"1 Month";
    puppy.popularity = 4;
    [puppies addObject:puppy];
    
    puppy = [[Puppy alloc] init];
    puppy.name = @"Bullet";
    puppy.age = @"3 Months";
    puppy.popularity = 3;
    [puppies addObject:puppy];
    
    UITabBarController *tabBarController = (UITabBarController *)self.window.rootViewController;
    UINavigationController *navigationController = [tabBarController viewControllers][1];
    
    PuppyListViewController *puppyListVC = [navigationController viewControllers][0];
    puppyListVC.pups = puppies;
    
    return YES;
}

@end
