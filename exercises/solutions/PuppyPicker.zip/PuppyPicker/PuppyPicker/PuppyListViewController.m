//
//  PuppyListViewController.m
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/12/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import "PuppyListViewController.h"
#import "Puppy.h"
#import "PuppyCell.h"

@interface PuppyListViewController ()

@end

@implementation PuppyListViewController

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.pups count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    PuppyCell *cell = (PuppyCell *)[tableView dequeueReusableCellWithIdentifier:@"PuppyCell"];
    
    Puppy *puppy = (self.pups)[indexPath.row];
    cell.nameLabel.text = puppy.name;
    cell.ageLabel.text = puppy.age;
    cell.popularity.image = [self imageForPopularityRating:puppy.popularity];
    
    return cell;
}

- (UIImage *)imageForPopularityRating:(int)rating
{
    switch (rating) {
        case 1: return [UIImage imageNamed:@"1StarSmall"];
        case 2: return [UIImage imageNamed:@"2StarsSmall"];
        case 3: return [UIImage imageNamed:@"3StarsSmall"];
        case 4: return [UIImage imageNamed:@"4StarsSmall"];
        case 5: return [UIImage imageNamed:@"5StarsSmall"];
    }
    return nil;
}

@end
