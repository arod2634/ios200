//
//  PuppyViewController.h
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/11/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import "PuppyPickerViewController.h"

@interface PuppyViewController : PuppyPickerViewController

@property (assign) int puppyToShow;

@end
