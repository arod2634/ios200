//
//  NewPuppyViewController.m
//  PuppyPicker
//
//  Created by Alex Rodriguez on 3/16/14.
//  Copyright (c) 2014 Alex Rodriguez. All rights reserved.
//

#import "NewPuppyViewController.h"
#import "Puppy.h"

@interface NewPuppyViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;

@end

@implementation NewPuppyViewController

- (void)viewDidLoad
{
    self.nameTextField.delegate = self;
}

- (IBAction)done:(id)sender
{
    Puppy *newPuppy = [[Puppy alloc] init];
    
    [self.delegate newPuppyViewController:self didAddPuppy:newPuppy];
}

- (IBAction)cancel:(id)sender
{
    [self.delegate newPuppyViewControllerDidCancel:self];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}

@end
